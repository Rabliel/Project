﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF.AnimeDiary.InputClasses;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Reflection;


namespace WPF.AnimeDiary
{
    class DataLoader
    {
        public List<AnimeSeries> ExtractData()
        {
            var SeriesList = new List<AnimeSeries>();

            /* Loading data from embedded file - CAN'T WRITE INTO EMBEDDED FILE -> ADDING NEW SERIES DOESN'T WORK */
            byte[] buffer = Properties.Resources.animes;
            string converted = Encoding.UTF8.GetString(buffer, 0, buffer.Length);
            var json = JsonConvert.DeserializeObject<Dictionary<string, object>>(converted);


            /* Loading data with file path (from GetPath from ViewModel) also enables saving and loading new series
             * through WPF
             * 
             * If you want to make this work all you have to do is this:
             * 1. copy the animes.json file from Resources directory (of WPF.AnimeDiary) to anywhere you want
             * 2. correct the path in AnimeSeriesViewModel.GetPath to the path of the copied file

            var json = JsonConvert.DeserializeObject<Dictionary<string, object>>(File.ReadAllText(AnimeSeriesViewModel.GetPath()));
            
            */

            if (json.ContainsKey("animes"))
            {
                var series = (JArray)json["animes"];

                foreach (var seriesData in series)
                {
                    var Aseries = new AnimeSeries();
                    var overview = new Overview();
                    var characters = new Characters();
                    var world = new World();
                    var details = new Details();
                    var char1 = new Character();
                    var char2 = new Character();

                    //overview
                    overview.Title = seriesData["title"].Value<string>();
                    overview.Cover = seriesData["cover"].Value<string>();
                    overview.Genre = seriesData["genre"].Value<string>();
                    overview.Story = seriesData["story"].Value<string>();
                    overview.PersonalRating = seriesData["personalRating"].Value<string>();
                    //characters
                    char1.Img = seriesData["charOneImg"].Value<string>();
                    char1.Info = seriesData["charOneDescription"].Value<string>();
                    char1.Name = seriesData["charOne"].Value<string>();
                    char2.Info = seriesData["charTwoDescription"].Value<string>();
                    char2.Name = seriesData["charTwo"].Value<string>();
                    char2.Img = seriesData["charTwoImg"].Value<string>();
                    //world
                    world.FirstWorldImg = seriesData["worldImgOne"].Value<string>();
                    world.SecondWorldImg = seriesData["worldImgTwo"].Value<string>();
                    world.ThirdWorldImg = seriesData["worldImgThree"].Value<string>();
                    world.FourthWorldImg = seriesData["worldImgFour"].Value<string>();
                    //details
                    details.Release = seriesData["release"].Value<string>();
                    details.Status = seriesData["status"].Value<string>();
                    details.Episodes = seriesData["episodes"].Value<string>();
                    details.Length = seriesData["length"].Value<string>();
                    details.Rating = seriesData["rating"].Value<string>();
                    details.Studio = seriesData["studio"].Value<string>();
                    details.Author = seriesData["author"].Value<string>();

                    characters.FirstCharacter = char1;
                    characters.SecondCharacter = char2;

                    Aseries.overview = overview;
                    Aseries.details = details;
                    Aseries.characters = characters;
                    Aseries.world = world;

                    SeriesList.Add(Aseries);
                }
            }

            return SeriesList;
        }

        public string ExtractDataToString()
        {
            return File.ReadAllText(AnimeSeriesViewModel.GetPath());
        }
    }
}
