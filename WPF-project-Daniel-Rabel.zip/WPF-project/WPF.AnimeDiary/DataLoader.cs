﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF.AnimeDiary.InputClasses;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Reflection;


namespace WPF.AnimeDiary
{
    class DataLoader
    {
        public List<AnimeSeries> ExtractData()
        {
            var SeriesList = new List<AnimeSeries>();

            var json = JsonConvert.DeserializeObject<Dictionary<string, object>>(File.ReadAllText(@"animes.json"));             

            if (json.ContainsKey("animes"))
            {
                var series = (JArray)json["animes"];

                foreach (var seriesData in series)
                {
                    var Aseries = new AnimeSeries();

                    Aseries.LoadDataFromJToken(seriesData);

                    SeriesList.Add(Aseries);
                }
            }

            return SeriesList;
        }

        public string ExtractDataToString()
        {
            return File.ReadAllText(@"animes.json");
        }
    }
}
