﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WPF.AnimeDiary.InputClasses
{
    class Overview
    {
        public string Title { get; set; }
        public string Cover { get; set; }
        public string Genre { get; set; }
        public string PersonalRating { get; set; }
        public string Story { get; set; }

        public void LoadDataFromJToken(JToken jToken)
        {
            Title = jToken["title"].Value<string>();
            Cover = jToken["cover"].Value<string>();
            Genre = jToken["genre"].Value<string>();
            Story = jToken["story"].Value<string>();
            PersonalRating = jToken["personalRating"].Value<string>();
        }
    }
}
