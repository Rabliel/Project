﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF.AnimeDiary.InputClasses
{
    class Overview
    {
        public string Title { get; set; }
        public string Cover { get; set; }
        public string Genre { get; set; }
        public string PersonalRating { get; set; }
        public string Story { get; set; }
    }
}
