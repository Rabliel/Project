﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WPF.AnimeDiary.InputClasses
{
    class Characters
    {
        public Character FirstCharacter { get; set; }
        public Character SecondCharacter { get; set; }

        public void LoadDataFromJToken(JToken jToken)
        {
            FirstCharacter = new Character();
            SecondCharacter = new Character();

            FirstCharacter.Img = jToken["charOneImg"].Value<string>();
            FirstCharacter.Info = jToken["charOneDescription"].Value<string>();
            FirstCharacter.Name = jToken["charOne"].Value<string>();
            SecondCharacter.Info = jToken["charTwoDescription"].Value<string>();
            SecondCharacter.Name = jToken["charTwo"].Value<string>();
            SecondCharacter.Img = jToken["charTwoImg"].Value<string>();
        }
    }
}
