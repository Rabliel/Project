﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WPF.AnimeDiary.InputClasses
{
    class Character
    {
        public string Img { get; set; }
        public string Name { get; set; }
        public string Info { get; set; }
    }
}
