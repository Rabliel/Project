﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WPF.AnimeDiary.InputClasses
{
    class World
    {
        public string FirstWorldImg { get; set; }
        public string SecondWorldImg { get; set; }
        public string ThirdWorldImg { get; set; }
        public string FourthWorldImg { get; set; }


        public void LoadDataFromJToken(JToken jtoken)
        {
            FirstWorldImg = jtoken["worldImgOne"].Value<string>();
            SecondWorldImg = jtoken["worldImgTwo"].Value<string>();
            ThirdWorldImg = jtoken["worldImgThree"].Value<string>();
            FourthWorldImg = jtoken["worldImgFour"].Value<string>();
        }
    }
}
