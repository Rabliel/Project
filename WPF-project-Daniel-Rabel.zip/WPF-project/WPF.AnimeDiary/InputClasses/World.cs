﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF.AnimeDiary.InputClasses
{
    class World
    {
        public string FirstWorldImg { get; set; }
        public string SecondWorldImg { get; set; }
        public string ThirdWorldImg { get; set; }
        public string FourthWorldImg { get; set; }
    }
}
