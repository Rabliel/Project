﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WPF.AnimeDiary.InputClasses
{
    class Details
    {
        public string Release { get; set; }
        public string Status { get; set; }
        public string Episodes { get; set; }
        public string Length { get; set; }
        public string Rating { get; set; }
        public string Studio { get; set; }
        public string Author { get; set; }

        public void LoadDataFromJToken(JToken jToken)
        {
            Release = jToken["release"].Value<string>();
            Status = jToken["status"].Value<string>();
            Episodes = jToken["episodes"].Value<string>();
            Length = jToken["length"].Value<string>();
            Rating = jToken["rating"].Value<string>();
            Studio = jToken["studio"].Value<string>();
            Author = jToken["author"].Value<string>();
        }




    }
}
