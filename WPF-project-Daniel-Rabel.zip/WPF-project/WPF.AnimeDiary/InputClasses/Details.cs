﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF.AnimeDiary.InputClasses
{
    class Details
    {
        public string Release { get; set; }
        public string Status { get; set; }
        public string Episodes { get; set; }
        public string Length { get; set; }
        public string Rating { get; set; }
        public string Studio { get; set; }
        public string Author { get; set; }
    }
}
