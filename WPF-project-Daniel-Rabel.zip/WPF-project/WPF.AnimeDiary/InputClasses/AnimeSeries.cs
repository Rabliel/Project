﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WPF.AnimeDiary.InputClasses
{
    class AnimeSeries
    {
        // OVERVIEW
        public Overview overview { get; set; }

        //CHARACTERS
        public Characters characters { get; set; }

        //WORLD
        public World world { get; set; }

        //DETAILS
        public Details details { get; set; }

        public void LoadDataFromJToken(JToken jToken)
        {
            overview = new Overview();
            characters = new Characters();
            world = new World();
            details = new Details();

            overview.LoadDataFromJToken(jToken);
            characters.LoadDataFromJToken(jToken);
            world.LoadDataFromJToken(jToken);
            details.LoadDataFromJToken(jToken);
        }
    }
}
