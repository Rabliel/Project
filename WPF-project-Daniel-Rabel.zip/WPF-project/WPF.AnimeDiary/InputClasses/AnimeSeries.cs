﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF.AnimeDiary.InputClasses
{
    class AnimeSeries
    {
        // OVERVIEW
        public Overview overview { get; set; }

        //CHARACTERS
        public Characters characters { get; set; }

        //WORLD
        public World world { get; set; }

        //DETAILS
        public Details details { get; set; }

    }
}
