﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;
using System.ComponentModel;
using System.IO;
using WPF.AnimeDiary.InputClasses;


namespace WPF.AnimeDiary
{
    class AnimeSeriesViewModel : INotifyPropertyChanged
    {
        //private ICommand _nextButtonCommand;
        //private ICommand _previousButtonCommand;
        private ICommand _overviewButtonCommand;
        private ICommand _charactersButtonCommand;
        private ICommand _worldButtonCommand;
        private ICommand _detailsButtonCommand;
        private ICommand _nextButtonCommand;
        private ICommand _previousButtonCommand;
        private ICommand _addButtonCommand;
        private ICommand _refreshButtonCommand;

        public event PropertyChangedEventHandler PropertyChanged;

        private List<AnimeSeries> _series;
        private int _displayedSeriesIndex;

        private bool _overviewVisible = true;
        private bool _charactersVisible = false;
        private bool _worldVisible = false;
        private bool _detailsVisible = false;
        private bool _addVisible = false;

        public AnimeSeriesViewModel()
        {
            _series = new DataLoader().ExtractData();
            _displayedSeriesIndex = 0;
        }

        public ICommand OverviewButtonCommand => _overviewButtonCommand ?? (_overviewButtonCommand = new CommandHandler(ShowOverview, () => !_overviewVisible));

        public ICommand CharactersButtonCommand => _charactersButtonCommand ?? (_charactersButtonCommand = new CommandHandler(ShowCharacters, () => !_charactersVisible));

        public ICommand WorldButtonCommand => _worldButtonCommand ?? (_worldButtonCommand = new CommandHandler(ShowWorld, () => !_worldVisible));

        public ICommand DetailsButtonCommand => _detailsButtonCommand ?? (_detailsButtonCommand = new CommandHandler(ShowDetails, () => !_detailsVisible));

        public ICommand NextButtonCommand => _nextButtonCommand ?? (_nextButtonCommand = new CommandHandler(ShowNextSeries, NextSeriesExists));

        public ICommand AddButtonCommand => _addButtonCommand ?? (_addButtonCommand = new CommandHandler(ShowAdd, () => !_addVisible));

        public ICommand PreviousButtonCommand => _previousButtonCommand ?? (_previousButtonCommand = new CommandHandler(ShowPreviousSeries, PreviousSeriesExists));

        public ICommand RefreshButtonCommand => _refreshButtonCommand ?? (_refreshButtonCommand = new CommandHandler(RefreshSeries, () => true));

        private void ShowOverview()
        {
            _overviewVisible = true;
            _charactersVisible = false;
            _worldVisible = false;
            _detailsVisible = false;
            _addVisible = false;
            NotifyMenuSectionsProperties();
        }
        private void ShowCharacters()
        {
            _overviewVisible = false;
            _charactersVisible = true;
            _worldVisible = false;
            _detailsVisible = false;
            _addVisible = false;
            NotifyMenuSectionsProperties();
        }
        private void ShowWorld()
        {
            _overviewVisible = false;
            _charactersVisible = false;
            _worldVisible = true;
            _detailsVisible = false;
            _addVisible = false;
            NotifyMenuSectionsProperties();
        }
        private void ShowDetails()
        {
            _overviewVisible = false;
            _charactersVisible = false;
            _worldVisible = false;
            _detailsVisible = true;
            _addVisible = false;
            NotifyMenuSectionsProperties();
        }

        private void ShowAdd()
        {
            _overviewVisible = false;
            _charactersVisible = false;
            _worldVisible = false;
            _detailsVisible = false;
            _addVisible = true;
            NotifyMenuSectionsProperties();
        }

        private bool NextSeriesExists()
        {
            return _displayedSeriesIndex + 1 < _series.Count;
        }

        private bool PreviousSeriesExists()
        {
            return _displayedSeriesIndex - 1 >= 0;
        }

        public void ShowNextSeries()
        {
            ShowOverview();
            _displayedSeriesIndex += 1;
            NotifyPropertyChanged("Serie");
        }

        public void ShowPreviousSeries()
        {
            ShowOverview();
            _displayedSeriesIndex -= 1;
            NotifyPropertyChanged("Serie");
        }

        public bool OverviewVisible => _overviewVisible;
        public bool CharactersVisible => _charactersVisible;
        public bool WorldVisible => _worldVisible;
        public bool DetailsVisible => _detailsVisible;
        public bool AddVisible => _addVisible;


        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void NotifyMenuSectionsProperties()
        {
            NotifyPropertyChanged("OverviewVisible");
            NotifyPropertyChanged("CharactersVisible");
            NotifyPropertyChanged("WorldVisible");
            NotifyPropertyChanged("DetailsVisible");
            NotifyPropertyChanged("AddVisible");
        }

        public List<AnimeSeries> Serie
        {
            get
            {
                var articles = _series.GetRange(_displayedSeriesIndex, 1);

                return articles;
            }
        }
        
        public static string GetPath()
        {
            return @"C:\Users\Daniel\Desktop\animes.json";
        }

        private void RefreshSeries()
        {
            _series = new DataLoader().ExtractData();
            ShowOverview();
            NotifyMenuSectionsProperties();
        }

    }
}
