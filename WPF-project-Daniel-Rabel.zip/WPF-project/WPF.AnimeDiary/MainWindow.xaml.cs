﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using WPF.AnimeDiary.InputClasses;

namespace WPF.AnimeDiary
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new AnimeSeriesViewModel();
        }


        //add new series into json file
        /*
         * important to note that this works only if there is only 1 array in json file
         * and the json is supposed to contain anime series as the one in Resources folder
         * 
         * Also works only if DataLoader is reading from filepath and not the embedded file
         * If you want to make this work all you have to do is this:
         * 1. copy the animes.json file from Resources directory (of WPF.AnimeDiary) to anywhere you want
         * 2. correct the path in AnimeSeriesViewModel.GetPath to the path of the copied file
         * 
        */
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            //styling all parts of anime series
            var overview = jsonizeOverview();
            var chars = jsonizeCharacters();
            var world = jsonizeWorld();
            var details = jsonizeDetails();

            //making viable entry into json
            var newAnime = ",{" + overview + chars + world + details + "}";       

            //getting content of json and finding correct position for new entry
            var json = new DataLoader().ExtractDataToString();
            var splitJson = json.Split(']');

            //inputting new entry to correct position and ensuring correct json format
            var output = splitJson[0] + newAnime + " ] " + splitJson[1];

            //outputing updated json into json file
            File.WriteAllText(@"animes.json", output);
            clearAllTB();
        }

        //styles the inputs into json viable string
        private string jsonize(string name,string text)
        {
            return String.Format("\"{0}\":\"{1}\"",name,text);
        }

        private string jsonizeOverview()
        {
            string output="";

            output = output + jsonize("title", titleTB.Text) + ",";
            output = output + jsonize("cover", coverTB.Text) + ",";
            output = output + jsonize("genre", genreTB.Text) + ",";
            output = output + jsonize("personalRating", personalTB.Text) + ",";
            output = output + jsonize("story", storyTB.Text) + ",";

            return output;
        }

        private string jsonizeCharacters()
        {
            string output = "";

            output = output + jsonize("charOneImg", charOneImgTB.Text) + ",";
            output = output + jsonize("charOne", charOneNameTB.Text) + ",";
            output = output + jsonize("charOneDescription", charOneInfoTB.Text) + ",";
            output = output + jsonize("charTwo", charTwoNameTB.Text) + ",";
            output = output + jsonize("charTwoImg", charTwoImgTB.Text) + ",";
            output = output + jsonize("charTwoDescription", charTwoInfoTB.Text) + ",";

            return output;
        }

        private string jsonizeWorld()
        {
            string output = "";

            output = output + jsonize("worldImgOne", worldOneTB.Text) + ",";
            output = output + jsonize("worldImgTwo", worldTwoTB.Text) + ",";
            output = output + jsonize("worldImgThree", worldThreeTB.Text) + ",";
            output = output + jsonize("worldImgFour", worldFourTB.Text) + ",";

            return output;
        }

        private string jsonizeDetails()
        {
            string output = "";

            output = output + jsonize("release", releaseTB.Text) + ",";
            output = output + jsonize("status", statusTB.Text) + ",";
            output = output + jsonize("episodes", episodesTB.Text) + ",";
            output = output + jsonize("length", lengthTB.Text) + ",";
            output = output + jsonize("rating", ratingTB.Text) + ",";
            output = output + jsonize("studio", studioTB.Text) + ",";
            output = output + jsonize("author", authorTB.Text);

            return output;
        }

        //Clears all textboxes in adding "page"
        private void clearAllTB()
        {
            //CLEAR OVERVIEW
            titleTB.Clear();
            coverTB.Clear();
            genreTB.Clear();
            personalTB.Clear();
            storyTB.Clear();

            charOneImgTB.Clear();
            charOneNameTB.Clear();
            charOneInfoTB.Clear();
            charTwoNameTB.Clear();
            charTwoImgTB.Clear();
            charTwoInfoTB.Clear();

            //CLEAR WORLD
            worldOneTB.Clear();
            worldTwoTB.Clear();
            worldThreeTB.Clear();
            worldFourTB.Clear();

            //CLEAN DETAILS
            releaseTB.Clear();
            statusTB.Clear();
            episodesTB.Clear();
            episodesTB.Clear();
            ratingTB.Clear();
            authorTB.Clear();
            studioTB.Clear();

        }
    }
}
